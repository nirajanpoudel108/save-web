<?php defined('_JEXEC') or die; ?>
<div id="home-slider" class="flexslider">
    <ul class="slides">
        <?php foreach ($list as $item) : ?>
            <li>
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 offset-md-2 text-center">
                            <div class="home-wrapper text-center">
                                <div class="">
                                        <h1><?php 
                                            echo $item->name; 
                                        ?></h1>
                                        <h4><?php echo $item->description; ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        <?php endforeach; ?>
    </ul>

    <div class="is-prev"><i class="ti-arrow-circle-left"></i></div>
    <div class="is-next"><i class="ti-arrow-circle-right"></i></div>
</div>
