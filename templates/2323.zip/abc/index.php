<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.cassiopeia
 *
 * @copyright   (C) 2017 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <!--SEO Meta Tags-->
    <meta charset="utf-8" />
    <!-- SITE TITLE -->
    <title>Vakavia | Responsive Bootstrap Landing Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta content="Responsive Bootstrap Multi-Purpose Landing Page Template" name="description" />
    <meta name="keywords" content="Landing, Bootstrap, Landing page, Template, Registration, Landing">
    <meta content="Themesdesign" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />

    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Crete+Round:400i%7COpen+Sans:400,600,700" rel="stylesheet">


 <jdoc:include type="metas" />
    <jdoc:include type="styles" />


<?php

    $doc = JFactory::getDocument();
    $templatePath = JUri::base() . 'templates/' . $this->template;
$app   = Factory::getApplication();

    // CSS Files
    $doc->addStyleSheet($templatePath . '/css/bootstrap.min.css');
    $doc->addStyleSheet($templatePath . '/css/themify-icons.css');
    $doc->addStyleSheet($templatePath . '/css/owl.carousel.css');
    $doc->addStyleSheet($templatePath . '/css/owl.theme.default.min.css');
    $doc->addStyleSheet($templatePath . '/css/flexslider.css');
    $doc->addStyleSheet($templatePath . '/css/magnific-popup.css');
    $doc->addStyleSheet($templatePath . '/css/style.css');

    // IE8 Support (conditional)
    JHtml::_('script', $templatePath . '/js/html5shiv.js', ['conditional' => 'lt IE 9']);
    JHtml::_('script', $templatePath . '/js/respond.min.js', ['conditional' => 'lt IE 9']);
    $sitename = htmlspecialchars($app->get('sitename'), ENT_QUOTES, 'UTF-8');

    // Logo file or site title param
if ($this->params->get('logoFile')) {
    // If a logo is set in template params, use that
    $logo = '<img src="' . Uri::root(false) . htmlspecialchars($this->params->get('logoFile'), ENT_QUOTES) . '" alt="' . $sitename . '" height="24" loading="eager" decoding="async" />';
} else {
    // Otherwise fallback to your static logo
    $logo = '<img src="' . $this->baseurl . '/images/logo.png" alt="logo" height="24"  loading="eager" decoding="async" />';
}

?>


</head>

<body data-bs-spy="scroll" data-bs-target="#data-scroll">

    <!-- Loader -->
   <div id="preloader">
        <div id="status">
            <div class="spinner">Loading...</div>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky">
        <div class="container">
            <!-- LOGO -->
           
            <?php if ($this->params->get('brand', 1)) : ?>

                    <a class="navbar-brand logo text-uppercase" href="<?php echo $this->baseurl; ?>/">
                        <?php echo $logo; ?>
                    </a>
                   
                
        <?php endif; ?>


            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target=".navbar-collapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <i class="ti-menu"></i>
            </button>

            <div class="collapse navbar-collapse" id="data-scroll">
                
                 <?php if ($this->countModules('menu', true)) : ?>
                    <jdoc:include type="modules" name="menu" style="none" />
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- HOME -->
      <?php if ($this->countModules('banner', true)) : ?>
    <section class="home bg-home home-slider" id="home">

        <div class="bg-overlay"></div>

        <div class="container-fluid">
            <jdoc:include type="modules" name="banner" style="none" />
            
        </div>
        <!-- end container -->
    </section>
     <?php endif; ?>
    <!-- END HOME -->

    <section class="section" id="service">
        <jdoc:include type="component" />
    </section>
    

    <!-- FOOTER -->
    <footer class="bg-lightgray footer">
        <div class="container">
            <div class="row">

                <div class="col-md-4 col-sm-12">
                     <?php echo $logo; ?>
                    <p class="margin-t-20">
                        <?= $this->params->get('siteTitle') ?>
                    </p>

                    <ul class="list-inline social">
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="bg-twitter"><i class="ti-twitter-alt"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="bg-dribbble"><i class="ti-dribbble"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="bg-linkedin"><i class="ti-linkedin"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="bg-googleplus"><i class="ti-google"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="bg-facebook"><i class="ti-facebook"></i></a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-3 col-sm-6 offset-md-2">
                    <h5>Solutions</h5>
                    <ul class="list-unstyled footer-list">
                        <li><a href="">Web Design</a></li>
                        <li><a href="">Graphic Design</a></li>
                        <li><a href="">Power & Energy</a></li>
                        <li><a href="">Solar Power</a></li>
                        <li><a href="">Green energy</a></li>
                    </ul>
                </div>

                <div class="col-md-3 col-sm-6">
                    <h5>Useful Links</h5>
                    <ul class="list-unstyled footer-list">
                        <li><a href="">About Us</a></li>
                        <li><a href="">Help &amp; Support</a></li>
                        <li><a href="">Privacy Policy</a></li>
                        <li><a href="">Terms &amp; Conditions</a></li>
                        <li><a href="">FAQ</a></li>
                    </ul>
                </div>

            </div>
            <!-- end row -->

        </div>
        <!-- end container -->
    </footer>
    <!-- end FOOTER -->

    <!-- COPYRIGHT -->
    <div class="footer-alt bg-dark">
        <p class="copy-rights"><script>document.write(new Date().getFullYear());</script> © Vakavia.</p>
    </div>

<?php
    $doc = JFactory::getDocument();
    $templatePath = JUri::base() . 'templates/' . $this->template;

    // JS Files (placed at end by Joomla automatically)
    $doc->addScript($templatePath . '/js/jquery.min.js');
    $doc->addScript($templatePath . '/js/bootstrap.bundle.min.js');
    $doc->addScript($templatePath . '/js/jquery.sticky.js');
    $doc->addScript($templatePath . '/js/jquery.easing.1.3.min.js');
    $doc->addScript($templatePath . '/js/owl.carousel.min.js');
    $doc->addScript($templatePath . '/js/jquery.magnific-popup.min.js');
    $doc->addScript($templatePath . '/js/flexslider.js');
    $doc->addScript($templatePath . '/js/parsley.min.js');
    $doc->addScript($templatePath . '/js/app.js');
?>
    <jdoc:include type="scripts" />

</body>

</html>